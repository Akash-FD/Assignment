const All_Pakege = [
    {
        img:"room.jpg",
        h1:"Zulu Land cottages - near Curlies beach shack and shiva valley - Anjuna beach",
        room_details:{
            heading :"Akash with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"7.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 10,200",
        }
    },
    {
        img:"TreeHouse.jpg",
        h1:"Nirvana Hill Resort",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Very Good",
            total:"1240",
            rating:"7.5"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 8,500",
        }
    },
    {
        img:"itc.jpg",
        h1:"Storii By ITC Hotels Moira Riviera",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"7.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 10,200",
        }
    },
    {
        img:"beach.webp",
        h1:"Madrid Home 2 min walk to BeachOpens in new window",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"1580",
            rating:"6.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 8,200",
        }
    },
    {
        img:"panthouse.webp",
        h1:"Antarim Resort",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"8.5"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 15,200",
        }
    },
    {
        img:"lakepichola.jpg",
        h1:"Lake Pichola HotelOpens in new window",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"3580",
            rating:"8.1"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 12,200",
        }
    },
    {
        img:"room.jpg",
        h1:"Zulu Land cottages - near Curlies beach shack and shiva valley - Anjuna beach",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"7.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 10,200",
        }
    },
    {
        img:"room.jpg",
        h1:"Zulu Land cottages - near Curlies beach shack and shiva valley - Anjuna beach",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"7.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 10,200",
        }
    },
    {
        img:"room.jpg",
        h1:"Zulu Land cottages - near Curlies beach shack and shiva valley - Anjuna beach",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"7.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 10,200",
        }
    },
    {
        img:"room.jpg",
        h1:"Zulu Land cottages - near Curlies beach shack and shiva valley - Anjuna beach",
        room_details:{
            heading :"Cottage with Garden View",
            para:"2 entire bungalows • 2 bedrooms • 2 bathrooms 2 large double beds"
        },
        reviews:{
            compliment:"Good",
            total:"2580",
            rating:"7.8"

        },
        available:{
            stay:"1 night, 4 adults",
            cost:"₹ 10,200",
        }
    },
]





export default All_Pakege