import ApiCrud from "./Fake-Api/ApiCrud"
import Styling from "./Styling"
// import '../node_modules/bootstrap/dist/css/bootstrap.css'

// import ApiCrud from "./Fake-Api/ApiCrud"


function App() {


  return (
    <>
    <Styling/>
    <ApiCrud/>
    </>
  )
}

export default App
